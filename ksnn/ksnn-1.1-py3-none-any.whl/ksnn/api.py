import os,sys
import ctypes
from ksnn.kplatform.vim3.vim3_nn_api import vim3_nn
from numpy import *
from ksnn.types import *
import cv2 as cv
import numpy as np
import time
import gc

VERSION = 'v1.1'

def file_exist_judgment (file_path):
    '''Verify that the file exists
    '''
    if os.path.exists(file_path) == False:
        sys.exit(file_path + ' not exist')

class KSNN:
    '''Neural Network control interfance

    Class KSNN is the control interface for Neural Network, 
    
    all NPU-related functions and operations are included in this class.

    Attributes: 
        board: Board model. Board model list: VIM3/VIM3L
    '''

    def __init__ (self, board=None):

        if board == None:
            print('default board is VIM3')
            self.board = ksnn_board.BOARD_VIM3
        elif board == 'VIM3' or 'VIM3L':
            self.board = ksnn_board.BOARD_VIM3
        else :
            sys.exit('Unsupported board !!!')

    def get_nn_version (self):
        '''Print Neural Network Api version

        Args:
            None

        Returns:
            string: version
        '''

        return VERSION


    def nn_init (self, library=None, model=None, level=0):
        '''Create Neural Network

        Args:
            library: (Only valid for VIM3/VIM3L) The path for your C static librarys
            model:  The path for your model file.(VIM3 is nbg file)
            level: Information printing level (0(default)/1/2)

        Returns:
            class: ksnn_stat

        '''

        if self.board == ksnn_board.BOARD_VIM3:
            if library :
                if os.path.exists(library) == False:
                    sys.exit('so lib \'' + library + '\' not exist')
                library = bytes(library,encoding='utf-8')
            else :
                sys.exit('Board VIM3 requires parameter \'library\'')
            if model :
                if os.path.exists(model) == False:
                    sys.exit('nb file \'' + model + '\' not exist')
                model = bytes(model,encoding='utf-8')
            else :
                sys.exit('Board VIM3 requires parameter \'model\'')
            if level > 1:
                os.environ['VIV_VX_DEBUG_LEVEL']='1'
                os.environ['VIV_VX_PROFILE']='1'
            else:
                os.environ['VIV_VX_DEBUG_LEVEL']='0'
                os.environ['VIV_VX_PROFILE']='0'
            self.ksnn_api = vim3_nn()
            val = self.ksnn_api.neural_network_create(library, model, level)
            if val == 0 :
                return ksnn_stat.STAT_SUCCESS
            else :
                return ksnn_stat.STAT_FAIL
        sys.exit('Unsupported board !!!')

    def nn_set_inputs (self, img, platform=None, reorder='0 1 2', tensor=1):
        '''Convert the data and set it into neural network

        Args: 
            img: Mat format data
            platform: Your origin model platform
                        (TENSORFLOW/CAFFE/PYTORCH/DARKNET/ONNX/KERAS/TFLITE)
            reorder: Channel order('0 1 2'/'2 1 0')
            tensor: the input tensor numbers

        Returns:
            class: ksnn_stat
        '''

        if self.board == ksnn_board.BOARD_VIM3:
            for i in range(0,tensor):
                cv_img = img[i]
                input_tensor = self.ksnn_api.neural_network_get_input_tensor(i)
                if reorder == '0 1 2':
                    reorder_format = 0
                    h = input_tensor.size[2]
                    w = input_tensor.size[1]
                elif reorder == '2 1 0':
                    reorder_format = 1
                    h = input_tensor.size[0]
                    w = input_tensor.size[1]
                else :
                    sys.exit('reorder format error')

                try:
                    cv_img = cv.resize(cv_img, (h,w))
                except :
                    print('resize input pictures error !!!')
                    return ksnn_stat.STAT_FAIL

                pixel_data = np.asarray(cv_img, dtype=np.uint8)
                pixel_data = pixel_data.ctypes.data_as(ctypes. POINTER(ctypes.c_ubyte))
                if platform == 'TENSORFLOW' or platform == 'KERAS' or platform == 'TFLITE': #RGBRGBRGB
                    platform_format = 1
                elif platform == 'CAFFE' : #BBBGGGRRR
                    platform_format = 2
                elif platform == 'PYTORCH' or platform == 'DARKNET' or platform == 'ONNX' : #RRRGGGBBB
                    platform_format = 3
                else : #BGRBGRBGR
                    platform_format = 0

                val = self.ksnn_api.neural_network_set_input(pixel_data, reorder_format, platform_format, i)
                del pixel_data
                if val != 0 :
                    return ksnn_stat.STAT_FAIL
            return ksnn_stat.STAT_SUCCESS
        sys.exit('Unsupported board !!!')

    def nn_run ( self ):

        '''Run neural network

        Args:
            None

        Return:
            class: ksnn_stat

        '''

        if self.board == ksnn_board.BOARD_VIM3:
            val = self.ksnn_api.neural_network_process()
            if val == 0 :
                return ksnn_stat.STAT_SUCCESS
            else :
                return ksnn_stat.STAT_FAIL
        sys.exit('Unsupported board !!!')

    def nn_get_outputs (self, tensor=1, output_format=output_format.OUT_FORMAT_FLOAT32):

        '''Get outputs data after run Neural Network

        Args:
            tensor: Number of output layers. default is 1.
            output_format: Data format of output data
                            (OUT_FORMAT_UINT8/OUT_FORMAT_INT8/
                             OUT_FORMAT_INT16/OUT_FORMAT_FLOAT32(default)).

        Returns:
            list(): List of numpy arrays

        '''

        out_data = list()
        if self.board == ksnn_board.BOARD_VIM3:
            for i in range(tensor) :
                if output_format == output_format.OUT_FORMAT_UINT8 :
                    val = self.ksnn_api.neural_network_get_convert_tensor_data_format_u8(i)
                elif output_format == output_format.OUT_FORMAT_INT8 :
                    val = self.ksnn_api.neural_network_get_convert_tensor_data_format_i8(i)
                elif output_format == output_format.OUT_FORMAT_INT16 :
                    val  = self.ksnn_api.neural_network_get_convert_tensor_data_format_i16(i)
                elif output_format == output_format.OUT_FORMAT_FLOAT32 :
                    val = self.ksnn_api.neural_network_get_convert_tensor_data_format_f32(i)
                else :
                    sys.exit('Unknown out format, available formats: OUT_FORMAT_UINT8/OUT_FORMAT_INT8/OUT_FORMAT_INT16/OUT_FORMAT_FLOAT32')
                out_data.append(val)
                del val
            return out_data
        sys.exit('Unsupported board !!!')

    def nn_inference (self, cv_img, platform=None, reorder='0 1 2', input_tensor=1,output_tensor=1, output_format=output_format.OUT_FORMAT_FLOAT32):

        '''nn_inference implements a unified interface from input to output

        Args:
            cv_img: Mat format data list
            platform: Your origin model platform 
                        (TENSORFLOW/CAFFE/PYTORCH/DARKNET/ONNX/KERAS)
            reorder: Channel order('0 1 2'/'2 1 0')
            input_tensor: Number of output layers. default is 1.
            output_tensor: Number of output layers. default is 1.
            output_format: Data format of output data
                            (OUT_FORMAT_UINT8/OUT_FORMAT_INT8/
                             OUT_FORMAT_INT16/OUT_FORMAT_FLOAT32(default)).

        Returns:
            list(): List of numpy arrays
        '''

        if self.board == ksnn_board.BOARD_VIM3:
            res = self.nn_set_inputs(cv_img, platform=platform, reorder=reorder, tensor=input_tensor)
            if res == ksnn_stat.STAT_FAIL :
                sys.exit('Set nn inputs error !!!')

            res = self.nn_run()
            if res != ksnn_stat.STAT_SUCCESS :
                sys.exit('run neural network  error !!!')

            val =  self.nn_get_outputs(output_tensor, output_format)
            gc.collect()
            return val
        else :
            sys.exit('Unsupported board !!!')


    def nn_get_output_tensor_info (self, num):

        '''Get output tensor info

        Args:
            num: Which output layer

        Returns:
            class: npu_tensor
        '''

        if self.board == ksnn_board.BOARD_VIM3:
            return self.ksnn_api.neural_network_get_output_tensor(num)
        else :
            sys.exit('Unsupported board !!!')

