import os,sys
from ctypes import *
from ksnn.kplatform.vim3 import vim3_nn_types
import numpy as np

class vim3_nn:

    def neural_network_create(self, library, model, level):
        self.detect_so = CDLL(library)
        create = self.detect_so.NPU_CreateNeuralNetwork
        create.argtypes = [c_char_p, c_int]
        create.restype = c_int
        val = create(model, level)
        if vim3_nn_types.NPU_SUCCESS == val :
            return vim3_nn_types.NPU_SUCCESS
        else :
            return vim3_nn_types.NPU_FAILE

    def npu_tool_version(self):
        version = self.detect_so.NPU_version
        version.argtypes = []
        version.restype = c_char_p
        ver =  version()
        return ver

    def neural_network_pre_process( self, picture_path ):
        pre_process = self.detect_so.NPU_PreProcessNeuralNetwork
        pre_process.argtypes = [c_char_p]
        pre_process.restype = c_int
        val = pre_process(picture_path)
        if vim3_nn_types.NPU_SUCCESS == val :
            return vim3_nn_types.NPU_SUCCESS
        else :
            return vim3_nn_types.NPU_FAILE
        
    def neural_network_verify(self):
        verify = self.detect_so.NPU_VerifyGraph
        verify.argtypes = []
        verify.restype = c_int
        val = verify()
        if vim3_nn_types.NPU_SUCCESS == val :
            return vim3_nn_types.NPU_SUCCESS
        else :
            return vim3_nn_types.NPU_FAILE
    
    def neural_network_process(self):
        process_graph = self.detect_so.NPU_ProcessGraph
        process_graph.argtypes = []
        process_graph.restype = c_int
        val = process_graph()
        if vim3_nn_types.NPU_SUCCESS == val :
            return vim3_nn_types.NPU_SUCCESS
        else :
            return vim3_nn_types.NPU_FAILE
    
    def neural_network_post_process(self):
        post_process = self.detect_so.NPU_PostProcessNeuralNetwork
        post_process.argtypes = []
        post_process.restype = c_int
        val =  post_process()
        if vim3_nn_types.NPU_SUCCESS == val :
            return vim3_nn_types.NPU_SUCCESS
        else :
            return vim3_nn_types.NPU_FAILE

    def neural_network_get_output_tensor(self, i):
        get_tensor = self.detect_so.NPU_GetOutputTensor
        get_tensor.argtypes = [c_int]
        get_tensor.restype = vim3_nn_types.npu_tensor
        result = get_tensor(i)
        return result

    def neural_network_get_input_tensor(self, i):
        get_tensor = self.detect_so.NPU_GetInputTensor
        get_tensor.argtypes = [c_int]
        get_tensor.restype = vim3_nn_types.npu_tensor
        result = get_tensor(i)
        return result

    def neural_network_get_convert_tensor_data_format_u8(self, i):
        output_tensor = self.neural_network_get_output_tensor(i)
        convet_tensor_data = self.detect_so.NPU_ConvertTensorToData_U8
        convet_tensor_data.argtypes = [c_int, POINTER(c_ubyte)]
        convet_tensor_data.restype = c_int
        tensor_size = 1
        for index in range(output_tensor.dim_num) :
            tensor_size *= output_tensor.size[index]
        data_u8 = np.zeros(tensor_size,dtype=np.uint8)
        data_u8 = data_u8.ctypes.data_as(POINTER(c_ubyte))
        result = convet_tensor_data(i, data_u8)
        data_u8 = np.ctypeslib.as_array(data_u8, shape=(tensor_size,))
        return data_u8

    def neural_network_get_convert_tensor_data_format_i8(self, i):
        output_tensor = self.neural_network_get_output_tensor(i)
        convet_tensor_data = self.detect_so.NPU_ConvertTensorToData_I8
        convet_tensor_data.argtypes = [c_int, POINTER(c_byte)]
        convet_tensor_data.restype = c_int
        tensor_size = 1
        for index in range(output_tensor.dim_num) :
            tensor_size *= output_tensor.size[index]
        data_i8 = np.zeros(tensor_size, dtype=np.int8)
        data_i8 = data_i8.ctypes.data_as(POINTER(c_byte))
        result = convet_tensor_data(i, data_i8)
        data_i8 = np.ctypeslib.as_array(data_i8, shape=(tensor_size,))
        return data_i8


    def neural_network_get_convert_tensor_data_format_i16(self, i):
        output_tensor = self.neural_network_get_output_tensor(i)
        convet_tensor_data = self.detect_so.NPU_ConvertTensorToData_I16
        convet_tensor_data.argtypes = [c_int, POINTER(c_short)]
        convet_tensor_data.restype = c_int
        tensor_size = 1
        for index in range(output_tensor.dim_num) :
            tensor_size *= output_tensor.size[index]
        data_i16 = np.zeros(tensor_size, dtype=np.int16)
        data_i16 = data_i16.ctypes.data_as(POINTER(c_short))
        result = convet_tensor_data(i, data_i16)
        data_i16 = np.ctypeslib.as_array(data_i16, shape=(tensor_size,))
        return data_i16


    def neural_network_get_convert_tensor_data_format_f16(self, i):
        convet_tensor_data = self.detect_so.NPU_ConvertTensorToData_F16
        convet_tensor_data.argtypes = [c_int, POINTER(c_short)]
        convet_tensor_data.restype = c_int
        tensor_size = 1
        for index in range(output_tensor.dim_num) :
            tensor_size *= output_tensor.size[index]
        data_f16 = np.zeros(tensor_size, dtype=np.int16)

        data_f16 = data_i16.ctypes.data_as(POINTER(c_short))
        result = convet_tensor_data(i, data_f16)
        data_f16 = np.ctypeslib.as_array(data_f16, shape=(tensor_size,))
        return data_f16


    def neural_network_get_convert_tensor_data_format_f32(self, i):

        tensor_size = 1
        output_tensor = self.neural_network_get_output_tensor(i)
        for index in range(output_tensor.dim_num) :
            tensor_size *= output_tensor.size[index]
        convet_tensor_data = self.detect_so.NPU_ConvertTensorToData_F32
        convet_tensor_data.argtypes = [c_int, POINTER(c_float)]
        convet_tensor_data.restype = c_int
        data_fl32 = np.zeros(tensor_size, dtype=np.float32)
        data_fl32 = data_fl32.ctypes.data_as(POINTER(c_float))
        result = convet_tensor_data(i, data_fl32)
        data_fl32 = np.ctypeslib.as_array(data_fl32,shape=(tensor_size,))
        del output_tensor, tensor_size
        return data_fl32


    def neural_network_get_input_tensor_num(self):
        input_tensor_num = self.detect_so.NPU_GetInputTensorNum
        input_tensor_num.argtypes = []
        input_tensor_num.restype = c_int
        num = input_tensor_num()
        return num

    def neural_network_get_output_tensor_num(self):
        output_tensor_num = self.detect_so.NPU_GetOutputTensorNum
        output_tensor_num.argtypes = []
        output_tensor_num.restype = c_int
        num = output_tensor_num()
        return num

    def neural_network_set_input(self, data, reorder_format, platform_format, num):
        pre_process = self.detect_so.NPU_SetInput
        pre_process.argtypes = [POINTER(c_ubyte), c_int, c_int, c_int]
        pre_process.restype = c_int
        val = pre_process(data, reorder_format, platform_format, num)
        if vim3_nn_types.NPU_SUCCESS == val :
            return vim3_nn_types.NPU_SUCCESS
        else :
            return vim3_nn_types.NPU_FAILE


# ---------+ END OF Class neural_network +--------- 
