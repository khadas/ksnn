from enum import Enum, unique

class ksnn_stat(Enum):
    '''Neural Network stat Enum class
    '''

    STAT_SUCCESS = 0
    STAT_FAIL    = 1

class ksnn_board(Enum):
    '''Support Board List
    '''
    BOARD_UNKNOWN = 0
    BOARD_VIM3    = 1
    BOARD_VIM3L   = 2

class output_format(Enum):
    '''Support output format
    '''
    OUT_FORMAT_UINT8   = 0
    OUT_FORMAT_INT8    = 1
    OUT_FORMAT_INT16   = 2
    OUT_FORMAT_FLOAT32 = 3
